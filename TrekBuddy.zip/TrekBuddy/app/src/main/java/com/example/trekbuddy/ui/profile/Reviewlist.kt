package com.example.trekbuddy.ui.profile

data class Reviewlist(
    val placeName: String?,
    val tags: List<String>,
    val tagEdit: String?
)
