package com.example.trekbuddy.ui.profile

interface OnTagSelectionListener {
    fun onTagsSelected(selectedTags: List<String>)
}