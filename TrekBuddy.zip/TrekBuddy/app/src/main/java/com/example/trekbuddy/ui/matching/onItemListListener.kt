package com.example.trekbuddy.ui.matching

import com.example.trekbuddy.ui.SearchCourse

interface onItemListListener {
    fun onItemClicked(course: SearchCourse)
}